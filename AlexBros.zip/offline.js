﻿{
	"version": 1663551687,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/alex-sheet0.png",
		"images/alex-sheet1.png",
		"images/back-sheet0.png",
		"images/burger-sheet0.png",
		"images/base-sheet0.png",
		"images/fantasma-sheet0.png",
		"images/suelo-sheet0.png",
		"images/blockcoin-sheet0.png",
		"images/blockcoin-sheet1.png",
		"media/risa.ogg",
		"media/coin.ogg",
		"media/alexbros.ogg",
		"img_0016.jpg",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}